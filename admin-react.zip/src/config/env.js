const APIURL = 'localhost:2333'

export default APIURL