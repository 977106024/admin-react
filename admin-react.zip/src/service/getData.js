import React from 'react'
import axios from 'axios'
import qs from 'qs'
import apiUrl from '@/config/env'

/**
 * 获取登录二维码
 * @param url地址
 * @returns {AxiosPromise}
 */
export const qrLogin = (param) => (
    axios({
        method:'get',
        url:apiUrl + '/admin/Qrlogin',
        data:qs.stringify(param)
    })
)