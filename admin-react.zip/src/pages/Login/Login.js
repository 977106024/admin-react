import React from 'react'
import './Index.scss'
import Button from 'antd/lib/button';
import loginImg from '@/assets/images/login.png'
import {qrLogin} from '@/service/getData'
import $ from 'jquery'

export default class Login extends React.Component{
    constructor(props){
        super(props)
    }

    componentWillMount() {
        const data = {url:'baiud.com'}
        // qrLogin(data).then(res=>{
        //     console.log(res)
        // })
        $.ajax({
            url: 'http://localhost:2333/admin/QrLogin',
            type:'get',
            data:data,
            success:function(res){
                console.log(res)
            }
        })
    }

    render(){
        return(
            <section id="Login">
                <div className="content">
                    <img src={loginImg} alt="二维码"/>
                    <p>扫码进入</p>
                </div>
            </section>
        )
    }
}